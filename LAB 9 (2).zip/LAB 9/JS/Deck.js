
     var deckSize=52;
     var handSize=5;
      var cards = new Array(handSize);
      var suits = new Array(handSize);
      var values = new Array(handSize);

function getHand() {
   $("#hand").replaceWith("<div id='hand'></div>");
   deal();
   for (var i=0;i<handSize;i++)
      $("#hand").append(displayCard(i));
}

function deal() {

     var i,j; // Iterator for loops 
     var aRandomNumber;

      var uniqueNumbersRequired=handSize;
      var myString="";
// Get the cards
      for (i = 0; i < uniqueNumbersRequired;)
         {
         aRandomNumber=Math.floor(Math.random()*deckSize);
         cards[i]=aRandomNumber;
         j=0;
         while(cards[j]!=aRandomNumber)
            j++;
         if (i==j)
           {
            i++;
            //console.log("Found (" + i + ")" + cards[j]);
           }
         }


// Calculate suit and value for each card
      for (i = 0; i < uniqueNumbersRequired;i++)
           {
           suits[i]=Math.floor(cards[i]%4);
           values[i]=cards[i] % 13;
           }



}

function displayCard(cardNum)
{

var suit=suits[cardNum];
var value=values[cardNum];

var result="<img  class='field-item even' width=100 src=Cards/";
   switch(value)
   {
     case 0: result += "2_of_";break;
     case 1: result += "3_of_";break;
     case 2: result += "4_of_";break;
     case 3: result += "5_of_";break;
     case 4: result += "6_of_";break;
     case 5: result += "7_of_";break;
     case 6: result += "8_of_";break;
     case 7: result += "9_of_";break;
     case 8: result += "10_of_";break;
     case 9: result += "ace_of_";break;
     case 10: result += "jack_of_";break;
     case 11: result += "queen_of_";break;
     case 12: result += "king_of_";break;
}

   switch(suit)
   {
     case 0: result += "hearts.png>";break;
     case 1: result += "clubs.png>";break;
     case 2: result += "spades.png>";break;
     case 3: result += "diamonds.png>";break;
}

return result;
}

